package com.entity;

import java.util.Date;

public class Customer {
    private Integer id;

    private Date creatime;

    private String mobile;

    private String password;

    private Boolean enable;

    private Boolean idCardAuth;

    private String realName;

    private Boolean sex;

    private String idCard;

    private String drivingLicenseCard;

    private String idCardAdd;

    private String drivingLicenseAdd;

    private Boolean drivingLicenseType;

    private String username;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreatime() {
        return creatime;
    }

    public void setCreatime(Date creatime) {
        this.creatime = creatime;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public Boolean getIdCardAuth() {
        return idCardAuth;
    }

    public void setIdCardAuth(Boolean idCardAuth) {
        this.idCardAuth = idCardAuth;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName == null ? null : realName.trim();
    }

    public Boolean getSex() {
        return sex;
    }

    public void setSex(Boolean sex) {
        this.sex = sex;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard == null ? null : idCard.trim();
    }

    public String getDrivingLicenseCard() {
        return drivingLicenseCard;
    }

    public void setDrivingLicenseCard(String drivingLicenseCard) {
        this.drivingLicenseCard = drivingLicenseCard == null ? null : drivingLicenseCard.trim();
    }

    public String getIdCardAdd() {
        return idCardAdd;
    }

    public void setIdCardAdd(String idCardAdd) {
        this.idCardAdd = idCardAdd == null ? null : idCardAdd.trim();
    }

    public String getDrivingLicenseAdd() {
        return drivingLicenseAdd;
    }

    public void setDrivingLicenseAdd(String drivingLicenseAdd) {
        this.drivingLicenseAdd = drivingLicenseAdd == null ? null : drivingLicenseAdd.trim();
    }

    public Boolean getDrivingLicenseType() {
        return drivingLicenseType;
    }

    public void setDrivingLicenseType(Boolean drivingLicenseType) {
        this.drivingLicenseType = drivingLicenseType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }
}