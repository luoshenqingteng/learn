package com.entity;

import java.math.BigDecimal;
import java.util.Date;

public class PetrolFillRecord {
    private Integer id;

    private Date creatime;

    private Integer customerId;

    private Integer petrolStationAndPetrolId;

    private BigDecimal amount;

    private String photoAdd;

    private Boolean audicStatus;

    private Date audicTime;

    private Boolean paymentStatus;

    private Date paymentTime;

    private Integer petrolStationId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreatime() {
        return creatime;
    }

    public void setCreatime(Date creatime) {
        this.creatime = creatime;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getPetrolStationAndPetrolId() {
        return petrolStationAndPetrolId;
    }

    public void setPetrolStationAndPetrolId(Integer petrolStationAndPetrolId) {
        this.petrolStationAndPetrolId = petrolStationAndPetrolId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPhotoAdd() {
        return photoAdd;
    }

    public void setPhotoAdd(String photoAdd) {
        this.photoAdd = photoAdd == null ? null : photoAdd.trim();
    }

    public Boolean getAudicStatus() {
        return audicStatus;
    }

    public void setAudicStatus(Boolean audicStatus) {
        this.audicStatus = audicStatus;
    }

    public Date getAudicTime() {
        return audicTime;
    }

    public void setAudicTime(Date audicTime) {
        this.audicTime = audicTime;
    }

    public Boolean getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(Boolean paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Integer getPetrolStationId() {
        return petrolStationId;
    }

    public void setPetrolStationId(Integer petrolStationId) {
        this.petrolStationId = petrolStationId;
    }
}