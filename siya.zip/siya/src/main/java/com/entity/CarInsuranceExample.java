package com.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CarInsuranceExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CarInsuranceExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUsernameIsNull() {
            addCriterion("username is null");
            return (Criteria) this;
        }

        public Criteria andUsernameIsNotNull() {
            addCriterion("username is not null");
            return (Criteria) this;
        }

        public Criteria andUsernameEqualTo(String value) {
            addCriterion("username =", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotEqualTo(String value) {
            addCriterion("username <>", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameGreaterThan(String value) {
            addCriterion("username >", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("username >=", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameLessThan(String value) {
            addCriterion("username <", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameLessThanOrEqualTo(String value) {
            addCriterion("username <=", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameLike(String value) {
            addCriterion("username like", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotLike(String value) {
            addCriterion("username not like", value, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameIn(List<String> values) {
            addCriterion("username in", values, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotIn(List<String> values) {
            addCriterion("username not in", values, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameBetween(String value1, String value2) {
            addCriterion("username between", value1, value2, "username");
            return (Criteria) this;
        }

        public Criteria andUsernameNotBetween(String value1, String value2) {
            addCriterion("username not between", value1, value2, "username");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseIsNull() {
            addCriterion("drive_license is null");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseIsNotNull() {
            addCriterion("drive_license is not null");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseEqualTo(String value) {
            addCriterion("drive_license =", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseNotEqualTo(String value) {
            addCriterion("drive_license <>", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseGreaterThan(String value) {
            addCriterion("drive_license >", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseGreaterThanOrEqualTo(String value) {
            addCriterion("drive_license >=", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseLessThan(String value) {
            addCriterion("drive_license <", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseLessThanOrEqualTo(String value) {
            addCriterion("drive_license <=", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseLike(String value) {
            addCriterion("drive_license like", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseNotLike(String value) {
            addCriterion("drive_license not like", value, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseIn(List<String> values) {
            addCriterion("drive_license in", values, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseNotIn(List<String> values) {
            addCriterion("drive_license not in", values, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseBetween(String value1, String value2) {
            addCriterion("drive_license between", value1, value2, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andDriveLicenseNotBetween(String value1, String value2) {
            addCriterion("drive_license not between", value1, value2, "driveLicense");
            return (Criteria) this;
        }

        public Criteria andIdCardIsNull() {
            addCriterion("id_card is null");
            return (Criteria) this;
        }

        public Criteria andIdCardIsNotNull() {
            addCriterion("id_card is not null");
            return (Criteria) this;
        }

        public Criteria andIdCardEqualTo(Integer value) {
            addCriterion("id_card =", value, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardNotEqualTo(Integer value) {
            addCriterion("id_card <>", value, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardGreaterThan(Integer value) {
            addCriterion("id_card >", value, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardGreaterThanOrEqualTo(Integer value) {
            addCriterion("id_card >=", value, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardLessThan(Integer value) {
            addCriterion("id_card <", value, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardLessThanOrEqualTo(Integer value) {
            addCriterion("id_card <=", value, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardIn(List<Integer> values) {
            addCriterion("id_card in", values, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardNotIn(List<Integer> values) {
            addCriterion("id_card not in", values, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardBetween(Integer value1, Integer value2) {
            addCriterion("id_card between", value1, value2, "idCard");
            return (Criteria) this;
        }

        public Criteria andIdCardNotBetween(Integer value1, Integer value2) {
            addCriterion("id_card not between", value1, value2, "idCard");
            return (Criteria) this;
        }

        public Criteria andLicensePlateIsNull() {
            addCriterion("license_plate is null");
            return (Criteria) this;
        }

        public Criteria andLicensePlateIsNotNull() {
            addCriterion("license_plate is not null");
            return (Criteria) this;
        }

        public Criteria andLicensePlateEqualTo(String value) {
            addCriterion("license_plate =", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateNotEqualTo(String value) {
            addCriterion("license_plate <>", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateGreaterThan(String value) {
            addCriterion("license_plate >", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateGreaterThanOrEqualTo(String value) {
            addCriterion("license_plate >=", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateLessThan(String value) {
            addCriterion("license_plate <", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateLessThanOrEqualTo(String value) {
            addCriterion("license_plate <=", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateLike(String value) {
            addCriterion("license_plate like", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateNotLike(String value) {
            addCriterion("license_plate not like", value, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateIn(List<String> values) {
            addCriterion("license_plate in", values, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateNotIn(List<String> values) {
            addCriterion("license_plate not in", values, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateBetween(String value1, String value2) {
            addCriterion("license_plate between", value1, value2, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andLicensePlateNotBetween(String value1, String value2) {
            addCriterion("license_plate not between", value1, value2, "licensePlate");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeIsNull() {
            addCriterion("order_creatime is null");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeIsNotNull() {
            addCriterion("order_creatime is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeEqualTo(Date value) {
            addCriterion("order_creatime =", value, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeNotEqualTo(Date value) {
            addCriterion("order_creatime <>", value, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeGreaterThan(Date value) {
            addCriterion("order_creatime >", value, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeGreaterThanOrEqualTo(Date value) {
            addCriterion("order_creatime >=", value, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeLessThan(Date value) {
            addCriterion("order_creatime <", value, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeLessThanOrEqualTo(Date value) {
            addCriterion("order_creatime <=", value, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeIn(List<Date> values) {
            addCriterion("order_creatime in", values, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeNotIn(List<Date> values) {
            addCriterion("order_creatime not in", values, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeBetween(Date value1, Date value2) {
            addCriterion("order_creatime between", value1, value2, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderCreatimeNotBetween(Date value1, Date value2) {
            addCriterion("order_creatime not between", value1, value2, "orderCreatime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeIsNull() {
            addCriterion("order_endtime is null");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeIsNotNull() {
            addCriterion("order_endtime is not null");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeEqualTo(Date value) {
            addCriterion("order_endtime =", value, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeNotEqualTo(Date value) {
            addCriterion("order_endtime <>", value, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeGreaterThan(Date value) {
            addCriterion("order_endtime >", value, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("order_endtime >=", value, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeLessThan(Date value) {
            addCriterion("order_endtime <", value, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeLessThanOrEqualTo(Date value) {
            addCriterion("order_endtime <=", value, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeIn(List<Date> values) {
            addCriterion("order_endtime in", values, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeNotIn(List<Date> values) {
            addCriterion("order_endtime not in", values, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeBetween(Date value1, Date value2) {
            addCriterion("order_endtime between", value1, value2, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andOrderEndtimeNotBetween(Date value1, Date value2) {
            addCriterion("order_endtime not between", value1, value2, "orderEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeIsNull() {
            addCriterion("insurance_creatime is null");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeIsNotNull() {
            addCriterion("insurance_creatime is not null");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeEqualTo(Date value) {
            addCriterion("insurance_creatime =", value, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeNotEqualTo(Date value) {
            addCriterion("insurance_creatime <>", value, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeGreaterThan(Date value) {
            addCriterion("insurance_creatime >", value, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeGreaterThanOrEqualTo(Date value) {
            addCriterion("insurance_creatime >=", value, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeLessThan(Date value) {
            addCriterion("insurance_creatime <", value, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeLessThanOrEqualTo(Date value) {
            addCriterion("insurance_creatime <=", value, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeIn(List<Date> values) {
            addCriterion("insurance_creatime in", values, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeNotIn(List<Date> values) {
            addCriterion("insurance_creatime not in", values, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeBetween(Date value1, Date value2) {
            addCriterion("insurance_creatime between", value1, value2, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceCreatimeNotBetween(Date value1, Date value2) {
            addCriterion("insurance_creatime not between", value1, value2, "insuranceCreatime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeIsNull() {
            addCriterion("insurance_endtime is null");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeIsNotNull() {
            addCriterion("insurance_endtime is not null");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeEqualTo(Date value) {
            addCriterion("insurance_endtime =", value, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeNotEqualTo(Date value) {
            addCriterion("insurance_endtime <>", value, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeGreaterThan(Date value) {
            addCriterion("insurance_endtime >", value, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("insurance_endtime >=", value, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeLessThan(Date value) {
            addCriterion("insurance_endtime <", value, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeLessThanOrEqualTo(Date value) {
            addCriterion("insurance_endtime <=", value, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeIn(List<Date> values) {
            addCriterion("insurance_endtime in", values, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeNotIn(List<Date> values) {
            addCriterion("insurance_endtime not in", values, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeBetween(Date value1, Date value2) {
            addCriterion("insurance_endtime between", value1, value2, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andInsuranceEndtimeNotBetween(Date value1, Date value2) {
            addCriterion("insurance_endtime not between", value1, value2, "insuranceEndtime");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Boolean value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Boolean value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Boolean value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Boolean value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Boolean value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Boolean value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Boolean> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Boolean> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Boolean value1, Boolean value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Boolean value1, Boolean value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}