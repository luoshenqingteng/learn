package com.entity;

import lombok.Data;

@Data
public class Auth {
	private String name;
	private String ahref;
	

}
