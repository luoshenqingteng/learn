package com.entity;

import lombok.Data;
import lombok.experimental.PackagePrivate;

/**
 * һ���˵���Ŀ
 * @author yaoluo
 *
 */

@Data
public class Permission {
	
	private Integer id;
	private String pname;
    private Integer role_id;
}
