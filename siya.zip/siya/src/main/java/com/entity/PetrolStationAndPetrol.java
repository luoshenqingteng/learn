package com.entity;

import java.math.BigDecimal;
import java.util.Date;

public class PetrolStationAndPetrol {
    private Integer id;

    private Date creatime;

    private Integer petrolStationId;

    private Integer petrolId;

    private Boolean enable;

    private BigDecimal unitPrice;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreatime() {
        return creatime;
    }

    public void setCreatime(Date creatime) {
        this.creatime = creatime;
    }

    public Integer getPetrolStationId() {
        return petrolStationId;
    }

    public void setPetrolStationId(Integer petrolStationId) {
        this.petrolStationId = petrolStationId;
    }

    public Integer getPetrolId() {
        return petrolId;
    }

    public void setPetrolId(Integer petrolId) {
        this.petrolId = petrolId;
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }
}