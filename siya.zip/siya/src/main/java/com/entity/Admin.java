package com.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Admin {
	
	private Integer id;
	private String username;
	private String password;
    private Date creatime;
    private Integer status;
    private Integer gasId;
    private Integer roleId;
    

}
