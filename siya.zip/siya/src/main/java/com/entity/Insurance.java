package com.entity;

import java.util.Date;

public class Insurance {
    private Integer id;

    private String beneficiary;

    private Integer age;

    private String body;

    private String homeplace;

    private String occupation;

    private String company;

    private Date orderCreatime;

    private Date orderEndtime;

    private Date insuranceCreatime;

    private Date insuranceEndtime;

    private Integer customerId;

    private Boolean status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBeneficiary() {
        return beneficiary;
    }

    public void setBeneficiary(String beneficiary) {
        this.beneficiary = beneficiary == null ? null : beneficiary.trim();
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body == null ? null : body.trim();
    }

    public String getHomeplace() {
        return homeplace;
    }

    public void setHomeplace(String homeplace) {
        this.homeplace = homeplace == null ? null : homeplace.trim();
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation == null ? null : occupation.trim();
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company == null ? null : company.trim();
    }

    public Date getOrderCreatime() {
        return orderCreatime;
    }

    public void setOrderCreatime(Date orderCreatime) {
        this.orderCreatime = orderCreatime;
    }

    public Date getOrderEndtime() {
        return orderEndtime;
    }

    public void setOrderEndtime(Date orderEndtime) {
        this.orderEndtime = orderEndtime;
    }

    public Date getInsuranceCreatime() {
        return insuranceCreatime;
    }

    public void setInsuranceCreatime(Date insuranceCreatime) {
        this.insuranceCreatime = insuranceCreatime;
    }

    public Date getInsuranceEndtime() {
        return insuranceEndtime;
    }

    public void setInsuranceEndtime(Date insuranceEndtime) {
        this.insuranceEndtime = insuranceEndtime;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}