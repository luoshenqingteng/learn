package com.entity;

import java.util.List;

import lombok.Data;
/**
 * �˵���
 * @author yw
 *
 */
@Data
public class ZTree {

	private String name;
	private Boolean open=true;
	private List<Auth> children;
	
	
	
	
}
