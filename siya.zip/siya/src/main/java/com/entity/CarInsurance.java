package com.entity;

import java.util.Date;

public class CarInsurance {
    private Integer id;

    private String username;

    private String name;

    private String driveLicense;

    private Integer idCard;

    private String licensePlate;

    private Date orderCreatime;

    private Date orderEndtime;

    private Date insuranceCreatime;

    private Date insuranceEndtime;

    private Boolean status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getDriveLicense() {
        return driveLicense;
    }

    public void setDriveLicense(String driveLicense) {
        this.driveLicense = driveLicense == null ? null : driveLicense.trim();
    }

    public Integer getIdCard() {
        return idCard;
    }

    public void setIdCard(Integer idCard) {
        this.idCard = idCard;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate == null ? null : licensePlate.trim();
    }

    public Date getOrderCreatime() {
        return orderCreatime;
    }

    public void setOrderCreatime(Date orderCreatime) {
        this.orderCreatime = orderCreatime;
    }

    public Date getOrderEndtime() {
        return orderEndtime;
    }

    public void setOrderEndtime(Date orderEndtime) {
        this.orderEndtime = orderEndtime;
    }

    public Date getInsuranceCreatime() {
        return insuranceCreatime;
    }

    public void setInsuranceCreatime(Date insuranceCreatime) {
        this.insuranceCreatime = insuranceCreatime;
    }

    public Date getInsuranceEndtime() {
        return insuranceEndtime;
    }

    public void setInsuranceEndtime(Date insuranceEndtime) {
        this.insuranceEndtime = insuranceEndtime;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}