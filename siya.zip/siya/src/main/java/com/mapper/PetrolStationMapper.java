package com.mapper;

import com.entity.PetrolStation;
import com.entity.PetrolStationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PetrolStationMapper {
    int countByExample(PetrolStationExample example);

    int deleteByExample(PetrolStationExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PetrolStation record);

    int insertSelective(PetrolStation record);

    List<PetrolStation> selectByExample(PetrolStationExample example);

    PetrolStation selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PetrolStation record, @Param("example") PetrolStationExample example);

    int updateByExample(@Param("record") PetrolStation record, @Param("example") PetrolStationExample example);

    int updateByPrimaryKeySelective(PetrolStation record);

    int updateByPrimaryKey(PetrolStation record);
}