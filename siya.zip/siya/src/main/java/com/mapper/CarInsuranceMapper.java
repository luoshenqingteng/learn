package com.mapper;

import com.entity.CarInsurance;
import com.entity.CarInsuranceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CarInsuranceMapper {
    int countByExample(CarInsuranceExample example);

    int deleteByExample(CarInsuranceExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CarInsurance record);

    int insertSelective(CarInsurance record);

    List<CarInsurance> selectByExample(CarInsuranceExample example);

    CarInsurance selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CarInsurance record, @Param("example") CarInsuranceExample example);

    int updateByExample(@Param("record") CarInsurance record, @Param("example") CarInsuranceExample example);

    int updateByPrimaryKeySelective(CarInsurance record);

    int updateByPrimaryKey(CarInsurance record);
    
    int updateCar(CarInsurance carInsurance);
}