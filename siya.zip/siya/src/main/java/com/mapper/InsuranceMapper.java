package com.mapper;

import com.entity.Insurance;
import com.entity.InsuranceExample;
import com.vo.InsuranceVo;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InsuranceMapper {
    int countByExample(InsuranceExample example);

    int deleteByExample(InsuranceExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Insurance record);

    int insertSelective(Insurance record);

    List<Insurance> selectByExample(InsuranceExample example);

    Insurance selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Insurance record, @Param("example") InsuranceExample example);

    int updateByExample(@Param("record") Insurance record, @Param("example") InsuranceExample example);

    int updateByPrimaryKeySelective(Insurance record);

    int updateByPrimaryKey(Insurance record);
    
    List<InsuranceVo> getInsurance(InsuranceVo insuranceVo);
    
    int updateInsurance(Insurance insurance);
}