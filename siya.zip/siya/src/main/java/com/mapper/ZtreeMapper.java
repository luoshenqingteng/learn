package com.mapper;

import java.util.List;

import com.entity.Admin;
import com.entity.Auth;
import com.entity.ZTree;




public interface ZtreeMapper {
	
	public List<Auth> getZtree();

}
