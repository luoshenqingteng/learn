package com.mapper;

import com.entity.InformationKind;
import com.entity.InformationKindExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InformationKindMapper {
    int countByExample(InformationKindExample example);

    int deleteByExample(InformationKindExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InformationKind record);

    int insertSelective(InformationKind record);

    List<InformationKind> selectByExample(InformationKindExample example);

    InformationKind selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InformationKind record, @Param("example") InformationKindExample example);

    int updateByExample(@Param("record") InformationKind record, @Param("example") InformationKindExample example);

    int updateByPrimaryKeySelective(InformationKind record);

    int updateByPrimaryKey(InformationKind record);
}