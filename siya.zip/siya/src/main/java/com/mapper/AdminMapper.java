package com.mapper;

import com.entity.Admin;

public interface AdminMapper {

	//登陆
	public Admin loginUser(Admin admin);
	
	
	
}
