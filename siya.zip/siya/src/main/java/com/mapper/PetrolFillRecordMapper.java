package com.mapper;

import com.entity.PetrolFillRecord;
import com.entity.PetrolFillRecordExample;
import com.vo.PetrolFillRecordVo;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PetrolFillRecordMapper {
    int countByExample(PetrolFillRecordExample example);

    int deleteByExample(PetrolFillRecordExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PetrolFillRecord record);

    int insertSelective(PetrolFillRecord record);

    List<PetrolFillRecord> selectByExample(PetrolFillRecordExample example);

    PetrolFillRecord selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PetrolFillRecord record, @Param("example") PetrolFillRecordExample example);

    int updateByExample(@Param("record") PetrolFillRecord record, @Param("example") PetrolFillRecordExample example);

    int updateByPrimaryKeySelective(PetrolFillRecord record);

    int updateByPrimaryKey(PetrolFillRecord record);
    
    List<PetrolFillRecordVo> getAllPetrol(PetrolFillRecordVo PetrolFillRecordVo);
    
    int getStatus(PetrolFillRecord petrolFillRecord);
    
}