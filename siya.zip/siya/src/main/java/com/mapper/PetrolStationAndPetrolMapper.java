package com.mapper;

import com.entity.PetrolStationAndPetrol;
import com.entity.PetrolStationAndPetrolExample;
import com.vo.PetrolFillRecordVo;
import com.vo.PetrolStationAndPetrolVo;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PetrolStationAndPetrolMapper {
    int countByExample(PetrolStationAndPetrolExample example);

    int deleteByExample(PetrolStationAndPetrolExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PetrolStationAndPetrol record);

    int insertSelective(PetrolStationAndPetrol record);

    List<PetrolStationAndPetrol> selectByExample(PetrolStationAndPetrolExample example);

    PetrolStationAndPetrol selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PetrolStationAndPetrol record, @Param("example") PetrolStationAndPetrolExample example);

    int updateByExample(@Param("record") PetrolStationAndPetrol record, @Param("example") PetrolStationAndPetrolExample example);

    int updateByPrimaryKeySelective(PetrolStationAndPetrol record);

    int updateByPrimaryKey(PetrolStationAndPetrol record);
    
    List<PetrolStationAndPetrolVo> getStationPetrol(PetrolStationAndPetrolVo PetrolStationAndPetrolVo);
}