package com.mapper;

import com.entity.Information;
import com.entity.InformationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InformationMapper {
    int countByExample(InformationExample example);

    int deleteByExample(InformationExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Information record);

    int insertSelective(Information record);

    List<Information> selectByExample(InformationExample example);

    Information selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Information record, @Param("example") InformationExample example);

    int updateByExample(@Param("record") Information record, @Param("example") InformationExample example);

    int updateByPrimaryKeySelective(Information record);

    int updateByPrimaryKey(Information record);
    
    List<Information> getAllInsurance(Integer informationKindId);
    
    //保险资讯
    List<Information> getInsuranceInformation(Information information);
    
    // 法律咨询
    List<Information> getlawInformation(Information information);
    // 平台咨询
    List<Information> getPlatorInformation(Information information);
    // 油价咨询
    List<Information> getOliInformation(Information information);
    // 气体行业咨询
    List<Information> getGasInformation(Information information);
    
    
    //插入
  	int insertUser(Information information);
}