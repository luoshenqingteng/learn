package com.mapper;

import com.entity.Petrol;
import com.entity.PetrolExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PetrolMapper {
    int countByExample(PetrolExample example);

    int deleteByExample(PetrolExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Petrol record);

    int insertSelective(Petrol record);

    List<Petrol> selectByExample(PetrolExample example);

    Petrol selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Petrol record, @Param("example") PetrolExample example);

    int updateByExample(@Param("record") Petrol record, @Param("example") PetrolExample example);

    int updateByPrimaryKeySelective(Petrol record);

    int updateByPrimaryKey(Petrol record);
}