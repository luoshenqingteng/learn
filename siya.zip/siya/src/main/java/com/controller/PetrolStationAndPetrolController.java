package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageInfo;
import com.mapper.PetrolStationAndPetrolMapper;
import com.service.PetrolStationAndPetrolService;
import com.vo.PetrolStationAndPetrolVo;

@Controller
@RequestMapping("StationPetrol")
public class PetrolStationAndPetrolController {
	
	
	@Autowired
	private PetrolStationAndPetrolService petrolStationAndPetrolService;
	
	@RequestMapping("getStationPetrol")
	public ModelAndView getStationPetrol(Integer now,Integer size,PetrolStationAndPetrolVo PetrolStationAndPetrolVo,
			String address,String name,String cname) {
		
		ModelAndView mView = new ModelAndView("sPetrol");
		PageInfo<PetrolStationAndPetrolVo> pageInfo = petrolStationAndPetrolService.getStationPetrol(now, size, PetrolStationAndPetrolVo, address, name, cname);
		mView.addObject("pageInfo", pageInfo);
		mView.addObject("address", address);
		mView.addObject("name", name);
		mView.addObject("cname", cname);
		return mView;
		
	}
	
	

}
