package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Information;
import com.github.pagehelper.PageInfo;
import com.service.GasInformation;
import com.service.InsuranceInformation;

@Controller
@RequestMapping("insurance")
public class GasInformationController {
	
	@Autowired
	private GasInformation gasInformation;
	
	@RequestMapping("gasInformation")
	public ModelAndView gasInformation(Integer size,Integer now,Information information) {
		ModelAndView mView =new ModelAndView("show_gas");
		PageInfo<Information> pageInfo = gasInformation.getGasInformation(size, now, information);
		mView.addObject("pageInfo", pageInfo);
		
		return mView;
	}

}
