package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.PetrolStation;
import com.github.pagehelper.PageInfo;
import com.service.PetrolStationService;

@Controller
@RequestMapping("station")
public class PetrolStationController {

	@Autowired
	private PetrolStationService petrolStationService;
	
	
	@RequestMapping("getAllStation")
	public ModelAndView  getAllPetrol(Integer now, Integer size,PetrolStation petrolStation,
			String address, String name, String tel) {
			
		ModelAndView mv = new ModelAndView("stationfile");
		PageInfo<PetrolStation> pageInfo = petrolStationService.getAllStation(now, size, petrolStation, address, tel, name);
		mv.addObject("pageInfo", pageInfo);
		mv.addObject("address", address);
		mv.addObject("name", name);
		mv.addObject("tel", tel);
		return mv;
		
	}

	
}
