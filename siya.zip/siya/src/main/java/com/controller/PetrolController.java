package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Petrol;
import com.github.pagehelper.PageInfo;
import com.service.PetrolService;

@Controller
@RequestMapping("Allpetrol")
public class PetrolController {
	
	
	@Autowired
	private PetrolService petrolService;
	
	@RequestMapping("getPetrolAll")
	public ModelAndView getAllPetrol(Integer now,Integer size,Petrol petrol,String name) {
		ModelAndView mView = new ModelAndView("petrol");
		PageInfo<Petrol> pageInfo = petrolService.getAllPetrol(now, size, petrol, name);
		mView.addObject("pageInfo", pageInfo);
		return mView;
	}
	

}
