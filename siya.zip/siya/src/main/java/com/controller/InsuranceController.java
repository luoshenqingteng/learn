package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
/**
 * ���ͼ�¼
 * @author yw
 *
 */
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Insurance;
import com.entity.PetrolFillRecord;
import com.github.pagehelper.PageInfo;
import com.service.InsuranceService;
import com.vo.InsuranceVo;
@Controller
@RequestMapping("insurance")
public class InsuranceController {

	
	@Autowired
	private InsuranceService insuranceService;
	
	@RequestMapping("getInsurance")
	public ModelAndView getInsurance(Integer now, Integer size, String realName, String beneficiary,
			String body, String homeplace, String occupation, String company) {
		
		ModelAndView mView =new ModelAndView("getInsurance");
		PageInfo<InsuranceVo> pageInfo = insuranceService.getInsurance(now, size, realName, beneficiary, body, homeplace, occupation, company);
		mView.addObject("pageInfo", pageInfo);
		mView.addObject("realName", realName);
		mView.addObject("beneficiary", beneficiary);
		mView.addObject("body", body);
		mView.addObject("homeplace", homeplace);
		mView.addObject("company", company);
		mView.addObject("occupation", occupation);
		
		
		
		
		return mView;
		
		
	}
	
	/**
	 * 进入修改页面
	 */
	@RequestMapping("toupdateInsurance")
	public String toupdate(Insurance insurance,Model model) {
		
		
		Insurance id = insuranceService.getById(insurance.getId());
		model.addAttribute("id", id);
		return "update_insurance";
	}
	@RequestMapping("updateInsurance")
	
	public String update(Insurance insurance ) {
		
		insuranceService.updateInsurance(insurance);
		return "redirect:getInsurance";
		
		
	}
	
}
