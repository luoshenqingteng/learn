package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Information;
import com.github.pagehelper.PageInfo;
import com.service.InsuranceInformation;
import com.service.LawInformation;

@Controller
@RequestMapping("insurance")
public class LawInformationController {
	
	@Autowired
	private LawInformation lawInformation;
	
	@RequestMapping("lawInformation")
	public ModelAndView lawInformation(Integer size,Integer now,Information information) {
		ModelAndView mView =new ModelAndView("show_law");
		PageInfo<Information> pageInfo = lawInformation.getlawInformation(size, now, information);
		mView.addObject("pageInfo", pageInfo);
		
		return mView;
	}

}
