package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Information;
import com.github.pagehelper.PageInfo;
import com.service.InsuranceInformation;

@Controller
@RequestMapping("insurance")
public class InsuranceInformationController {
	
	@Autowired
	private InsuranceInformation insuranceInformation;
	
	@RequestMapping("insuranceInformation")
	public ModelAndView insuranceInformation(Integer size,Integer now,Information information) {
		ModelAndView mView =new ModelAndView("show_insurance");
		PageInfo<Information> pageInfo = insuranceInformation.getInsuranceInformation(size, now, information);
		mView.addObject("pageInfo", pageInfo);
		
		return mView;
	}

}
