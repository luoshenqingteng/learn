package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.entity.Admin;
import com.service.AdminService;
/**
 * ��¼
 * @author yaoluo
 *
 */
@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("tologin")
	public String toLogin(){
		return "login";
	}
	
	@ResponseBody
	@RequestMapping("login")
	public String login(Admin admin,HttpSession session) {
		
		Admin loginUser = adminService.loginUser(admin,session);
		if(loginUser != null) {
			session.setAttribute("user", loginUser); 
			return "ok";
		}
		return "no";
		
	}
	
	

}
