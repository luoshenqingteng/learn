package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Information;
import com.github.pagehelper.PageInfo;
import com.service.InsuranceInformation;
import com.service.OliInformation;

@Controller
@RequestMapping("insurance")
public class OliInformationController {
	
	@Autowired
	private OliInformation oliInformation;
	
	@RequestMapping("oliInformation")
	public ModelAndView insuranceInformation(Integer size,Integer now,Information information) {
		ModelAndView mView =new ModelAndView("show_oli");
		PageInfo<Information> pageInfo = oliInformation.getOliInformation(size, now, information);
		mView.addObject("pageInfo", pageInfo);
		
		return mView;
	}

}
