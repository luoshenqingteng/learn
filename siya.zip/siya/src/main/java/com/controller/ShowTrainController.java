package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Insurance;
import com.entity.Train;
import com.github.pagehelper.PageInfo;
import com.service.TrainService;

@Controller
@RequestMapping("train")
public class ShowTrainController {
	
	@Autowired
	private TrainService trainService;
	
	@RequestMapping("getTrain")
	public ModelAndView getTrain(Integer now,Integer size,Train train,String author,String title) {
		ModelAndView mView =new ModelAndView("train");
		PageInfo<Train> pageInfo = trainService.getTrain(now, size, train, author, title);
		mView.addObject("pageInfo", pageInfo);
		mView.addObject("author", author);
		mView.addObject("title", title);
		
		
		return mView;
		
	}
	/**
	 * 进入修改页面
	 */
	@RequestMapping("toupdateTrain")
	public String toupdate(Train train,Model model) {
		
		
		Train id = trainService.getById(train.getId());
		model.addAttribute("id", id);
		return "update_train";
	}
	@RequestMapping("updateTrain")
	
	public String update(Train train ) {
		
		trainService.updateTrain(train);
		return "redirect:getTrain";
		
		
	}
	

}
