package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.CarInsurance;
import com.entity.Insurance;
import com.github.pagehelper.PageInfo;
import com.service.CarInsuranceService;

/**
 * ����
 * @author yw
 *
 */
@Controller
@RequestMapping("car")
public class CarInsuranceController {

	
	@Autowired
	private CarInsuranceService carInsuranceService;
	@RequestMapping("getCarInsurance")
	public ModelAndView getCarInsurance(Integer size, Integer now, String name, String driveLicense,
			String licensePlate) {
		ModelAndView mView = new ModelAndView("carInsurance");		
		PageInfo<CarInsurance> pageInfo = carInsuranceService.getCarInsurance(size, now, name, driveLicense, licensePlate);
		mView.addObject("pageInfo", pageInfo);
		mView.addObject("name", name);
		mView.addObject("licensePlate", licensePlate);
		mView.addObject("licensePlate", licensePlate);
		
		return mView;
		
	}
	
	/**
	 * 进入修改页面
	 */
	@RequestMapping("toupdateCar")
	public String toupdate(CarInsurance carInsurance,Model model) {
		
		
		CarInsurance id = carInsuranceService.getById(carInsurance.getId());
		model.addAttribute("id", id);
		return "update_carInsurance";
	}
	@RequestMapping("updateCar")
	
	public String update(CarInsurance carInsurance ) {
		
		carInsuranceService.updateCar(carInsurance);
		return "redirect:getCarInsurance";
		
		
	}
}
