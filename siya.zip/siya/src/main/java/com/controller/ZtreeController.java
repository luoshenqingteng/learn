package com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
/**
 * �˵���
 * @author yw
 *
 */
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.entity.Admin;
import com.entity.Auth;
import com.entity.ZTree;
import com.service.ZtreeService;
/**
 * �˵���Ŀչʾ
 * @author yw
 *
 */
@Controller
@RequestMapping("auth")
public class ZtreeController {
	
	@Autowired
	private ZtreeService ztreeService;
	
	@RequestMapping("queryAllztree")
	@ResponseBody
	public ZTree queryAllztree() {
		List<Auth> ztree = ztreeService.getZtree();
		ZTree zTree2 = new ZTree();
		zTree2.setChildren(ztree);
		return zTree2;
		
	}
	@RequestMapping("manManage")
	public String manManage(){
		return "main";
		
		
	}
	@RequestMapping("top")
	public String top(){
		return "top";
		
		
	}
	@RequestMapping("left")
	public String left(){
		return "left";
	}
	@RequestMapping("right")
	public String right() {
		return "right";
	}
	
	
	
	

}
