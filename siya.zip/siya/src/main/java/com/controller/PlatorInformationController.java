package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.entity.Information;
import com.github.pagehelper.PageInfo;
import com.service.InsuranceInformation;
import com.service.PlatorInformation;

@Controller
@RequestMapping("insurance")
public class PlatorInformationController {
	
	@Autowired
	private PlatorInformation platorInformation;
	
	@RequestMapping("platorInformation")
	public ModelAndView insuranceInformation(Integer size,Integer now,Information information) {
		ModelAndView mView =new ModelAndView("show_plator");
		PageInfo<Information> pageInfo = platorInformation.getPlatorInformation(size, now, information);
		mView.addObject("pageInfo", pageInfo);
		
		return mView;
	}

}
