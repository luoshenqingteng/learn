package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.entity.PetrolFillRecord;
import com.github.pagehelper.PageInfo;
import com.service.PetrolFileRecordService;
import com.vo.PetrolFillRecordVo;
/**
 * ���ͼ�¼
 * @author yw
 *
 */
@Controller
@RequestMapping("petrol")
public class PetrolFileRecordController {
	
	@Autowired
	private PetrolFileRecordService petrolFileRecordService;
	
	@RequestMapping("getAllPetrol")
	public ModelAndView  getAllPetrol(Integer now, Integer size, PetrolFillRecordVo petrolFillRecordVo,
			String address, String name, String realName) {
			
		ModelAndView mv = new ModelAndView("petrolefile");
		PageInfo<PetrolFillRecordVo> pageInfo = petrolFileRecordService.getAllPetrol(now, size, petrolFillRecordVo, address, name, realName);
		mv.addObject("pageInfo", pageInfo);
		mv.addObject("address", address);
		mv.addObject("name", name);
		mv.addObject("realName", realName);
		return mv;
		
	}
	/**
	 * 进入修改页面
	 */
	@RequestMapping("toupdate")
	public String toupdate(PetrolFillRecord petrolFillRecord,Model model) {
		
		
		PetrolFillRecord id = petrolFileRecordService.getById(petrolFillRecord.getId());
		model.addAttribute("id", id);
		return "update_petrolFileRecord";
	}
	@RequestMapping("update")
	
	public String update(PetrolFillRecord petrolFillRecord ) {
		
		petrolFileRecordService.updatePetrolFillRecord(petrolFillRecord);
		return "redirect:getAllPetrol";
		
		
	}
	

}
