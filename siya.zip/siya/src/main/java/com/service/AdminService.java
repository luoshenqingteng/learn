package com.service;

import javax.servlet.http.HttpSession;

import com.entity.Admin;

public interface AdminService {
	
	public Admin loginUser(Admin admin, HttpSession session);

}
