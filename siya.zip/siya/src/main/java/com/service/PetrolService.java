package com.service;

import com.entity.Petrol;
import com.entity.PetrolStation;
import com.github.pagehelper.PageInfo;

public interface PetrolService {
	
	PageInfo<Petrol> getAllPetrol(Integer now,Integer size,Petrol petrol,String name);

}
