package com.service;

import com.entity.PetrolStation;
import com.github.pagehelper.PageInfo;

public interface PetrolStationService {
	
	PageInfo<PetrolStation> getAllStation(Integer now,Integer size,PetrolStation petrolStation,String address,String tel,String name);

}
