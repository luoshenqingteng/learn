package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.CarInsurance;
import com.entity.CarInsuranceExample;
import com.entity.CarInsuranceExample.Criteria;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.CarInsuranceMapper;
import com.service.CarInsuranceService;
/**
 * ����
 * @author yw
 *
 */
@Service
public class CarInsuranceServiceImpl implements CarInsuranceService {
	
	
	@Autowired
	private CarInsuranceMapper carInsuranceMapper;
	
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;

	@Override
	public PageInfo<CarInsurance> getCarInsurance(Integer size, Integer now, String name, String driveLicense,
			String licensePlate) {
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		// ��ʼ��ҳ
		PageHelper.startPage(now,size);
		CarInsuranceExample example = new CarInsuranceExample();
		Criteria criteria = example.createCriteria();
		if(name != null && !"".equals(name)) {
			criteria.andNameLike("%"+name+"%");
		}
		if(driveLicense != null && !"".equals(driveLicense)) {
			criteria.andDriveLicenseLike("%"+driveLicense+"%");
		}
		if(licensePlate != null && !"".equals(licensePlate)) {
			criteria.andLicensePlateLike("%"+licensePlate+"%");
		}
		List<CarInsurance> list = carInsuranceMapper.selectByExample(example);
		PageInfo<CarInsurance> pageInfo = new PageInfo<>(list);
		return pageInfo;
	}

	@Override
	public CarInsurance getById(Integer id) {
		// TODO Auto-generated method stub
		return carInsuranceMapper.selectByPrimaryKey(id);
	}

	@Override
	public void updateCar(CarInsurance carInsurance) {
		// TODO Auto-generated method stub
		carInsuranceMapper.updateCar(carInsurance);
	}

}
