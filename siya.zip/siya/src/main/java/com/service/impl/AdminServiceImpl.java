package com.service.impl;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Admin;
import com.mapper.AdminMapper;
import com.service.AdminService;
/*
 * �û���¼
 */
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminMapper adminMapper;
	@Override
	public Admin loginUser(Admin admin,HttpSession session) {
		
		 Admin loginUser = adminMapper.loginUser(admin);
		 if(loginUser!=null) {
			 session.setAttribute("user", loginUser);
		 }
		 return loginUser;
	}

}
