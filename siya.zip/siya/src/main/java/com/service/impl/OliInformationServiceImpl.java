package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.Information;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.InformationMapper;
import com.mapper.InsuranceMapper;
import com.service.InsuranceInformation;
import com.service.OliInformation;
@Service
public class OliInformationServiceImpl implements OliInformation {

	
	
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;
	
	@Autowired
	private InformationMapper InformationMapper;
	
	@Override
	public PageInfo<Information> getOliInformation(Integer size, Integer now,Information information) {
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		
		PageHelper.startPage(now,size);
		List<Information> list = InformationMapper.getInsuranceInformation(information);
		PageInfo<Information> pageInfo = new PageInfo<>(list);
		return pageInfo;
	}

}
