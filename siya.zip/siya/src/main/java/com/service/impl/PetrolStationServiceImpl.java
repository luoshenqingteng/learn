package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.PetrolStation;
import com.entity.PetrolStationExample;
import com.entity.PetrolStationExample.Criteria;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.PetrolStationMapper;
import com.service.PetrolStationService;
/**
 * ����վ��Ϣ
 * @author yw
 *
 */
@Service
public class PetrolStationServiceImpl implements PetrolStationService{

	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;
	@Autowired
	private PetrolStationMapper petrolStationMapper;
	@Override
	public PageInfo<PetrolStation> getAllStation(Integer now, Integer size, PetrolStation petrolStation, String address,
			String tel,String name) {
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		// ��ʼ��ҳ
		PageHelper.startPage(now,size);
		// ��ʼģ����ѯ
		PetrolStationExample example = new PetrolStationExample();
		Criteria criteria = example.createCriteria();
		if(address != null && !"".equals(address)) {
			criteria.andAddressLike("%"+address+"%");
		}
		if(tel != null && !"".equals(tel)) {
			criteria.andTelLike("%"+tel+"%");
		}
		if(name != null && !"".equals(name)) {
			criteria.andNameLike("%"+name+"%");
		}
		List<PetrolStation> list = petrolStationMapper.selectByExample(example);
		PageInfo<PetrolStation> pageInfo = new PageInfo<>(list);
		return pageInfo;
	}
	
	

}
