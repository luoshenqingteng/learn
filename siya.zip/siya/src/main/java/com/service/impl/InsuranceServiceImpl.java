package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.Insurance;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.InsuranceMapper;
import com.service.InsuranceService;
import com.vo.InsuranceVo;
/**
 * ����
 * @author yw
 *
 */
@Service
public class InsuranceServiceImpl implements InsuranceService {
	
	@Autowired
	private InsuranceMapper insuranceMapper;
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;

	@Override
	public PageInfo<InsuranceVo> getInsurance(Integer now, Integer size, String realName, String beneficiary,
			String body, String homeplace, String occupation, String company) {
		
		
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		
		PageHelper.startPage(now,size);
		InsuranceVo insuranceVo= new InsuranceVo();
		if(realName != null && !"".equals(realName)){
			insuranceVo.setRealName(realName);
		}
		if(beneficiary != null && !"".equals(beneficiary)){
			insuranceVo.setBeneficiary(beneficiary);
		}
		if(body != null && !"".equals(body)){
			insuranceVo.setBody(body);
		}
		if(homeplace != null && !"".equals(homeplace)){
			insuranceVo.setHomeplace(homeplace);
		}
		if(occupation != null && !"".equals(occupation)){
			insuranceVo.setOccupation(occupation);
		}
		if(company != null && !"".equals(company)){
			insuranceVo.setCompany(company);
		}
		List<InsuranceVo> list = insuranceMapper.getInsurance(insuranceVo);
		PageInfo<InsuranceVo> pageInfo = new PageInfo<>(list);
		
		return pageInfo;
	}

	@Override
	public Insurance getById(Integer id) {
		
		return insuranceMapper.selectByPrimaryKey(id);
	}

	@Override
	public void updateInsurance(Insurance insurance) {
		
		insuranceMapper.updateInsurance(insurance);
		
	}
	

	

}
