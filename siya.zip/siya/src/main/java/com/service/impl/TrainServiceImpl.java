package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.Petrol;
import com.entity.Train;
import com.entity.TrainExample;
import com.entity.TrainExample.Criteria;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.TrainMapper;
import com.service.TrainService;
import com.vo.PetrolFillRecordVo;
@Service
public class TrainServiceImpl implements TrainService {

	
	
	@Autowired
	private TrainMapper trainMapper;
	
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;
	@Override
	public PageInfo<Train> getTrain(Integer now, Integer size, Train train, String author, String title) {
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		// 开始分页
		PageHelper.startPage(now,size);
		
		TrainExample example = new TrainExample();
		Criteria criteria = example.createCriteria();
		if(author != null && !"".equals(author)) {
			criteria.andAuthorLike("%"+author+"%");
		}
		if(title != null && !"".equals(title)) {
			criteria.andTitleLike("%"+author+"%");
		}
		List<Train> list = trainMapper.selectByExample(example);
		PageInfo<Train> pageInfo = new PageInfo<>(list);
		return pageInfo;
	}
	@Override
	public Train getById(Integer id) {
		
		return trainMapper.selectByPrimaryKey(id);
	}
	@Override
	public void updateTrain(Train train) {
		// TODO Auto-generated method stub
		trainMapper.updateTrain(train);
	}

}
