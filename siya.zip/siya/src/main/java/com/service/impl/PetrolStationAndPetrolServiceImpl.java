package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.PetrolStationAndPetrolMapper;
import com.service.PetrolStationAndPetrolService;
import com.vo.PetrolFillRecordVo;
import com.vo.PetrolStationAndPetrolVo;
/**
 * 
 * ����վ�͵���Ϣ
 * @author yw
 *
 */
@Service
public class PetrolStationAndPetrolServiceImpl implements PetrolStationAndPetrolService {
	
	@Autowired
	private PetrolStationAndPetrolMapper petrolStationAndPetrolMapper;
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;

	@Override
	public PageInfo<PetrolStationAndPetrolVo> getStationPetrol(Integer now, Integer size,
			PetrolStationAndPetrolVo PetrolStationAndPetrolVo, String address, String name, String cname) {
		
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		
		PageHelper.startPage(now,size);
		PetrolStationAndPetrolVo pe =new PetrolStationAndPetrolVo();
		if(address != null && !"".equals(address)){
			pe.setAddress(address);
		}
		if(name != null && !"".equals(name)){
			pe.setName(name);
		}
		if(cname != null && !"".equals(cname)){
			pe.setCname(cname);
		}
		List<PetrolStationAndPetrolVo> list = petrolStationAndPetrolMapper.getStationPetrol(PetrolStationAndPetrolVo);
		PageInfo<PetrolStationAndPetrolVo> pageInfo = new PageInfo<>(list);
		return pageInfo;
	}

}
