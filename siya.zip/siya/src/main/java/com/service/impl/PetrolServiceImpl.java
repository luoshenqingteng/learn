package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.Petrol;
import com.entity.PetrolExample;
import com.entity.PetrolStation;
import com.entity.PetrolExample.Criteria;
import com.entity.PetrolStationExample;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.PetrolMapper;
import com.service.PetrolService;
/**
 * �͵�����
 * @author yw
 *
 */
@Service
public class PetrolServiceImpl implements PetrolService {
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;
	@Autowired
	private PetrolMapper petrolMapper;

	@Override
	public PageInfo<Petrol> getAllPetrol(Integer now, Integer size, Petrol petrol, String name) {
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		// ��ʼ��ҳ
		PageHelper.startPage(now,size);
		// ��ʼģ����ѯ
		PetrolExample example = new PetrolExample();
		Criteria criteria = example.createCriteria();
		if(name != null && !"".equals(name)) {
			criteria.andNameLike("%"+name+"%");
		}
		List<Petrol> list = petrolMapper.selectByExample(example);
		PageInfo<Petrol> pageInfo = new PageInfo<>(list);
		
		return pageInfo;
	}
	

}
