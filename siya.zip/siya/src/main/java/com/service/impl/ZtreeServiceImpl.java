package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Auth;
import com.mapper.ZtreeMapper;
import com.service.ZtreeService;
/**
 * ��߲˵���
 * @author Ҧ��
 *
 */
@Service
public class ZtreeServiceImpl implements ZtreeService {
	
	@Autowired
	private ZtreeMapper ztreeMapper;

	@Override
	public List<Auth> getZtree() {
		
		return ztreeMapper.getZtree();
	}

}
