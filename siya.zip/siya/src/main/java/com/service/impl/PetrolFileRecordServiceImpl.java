package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.entity.PetrolFillRecord;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mapper.PetrolFillRecordMapper;
import com.service.PetrolFileRecordService;
import com.vo.PetrolFillRecordVo;


/**
 * 加油记录
 * @author yw
 *
 */
@Service
public class PetrolFileRecordServiceImpl implements PetrolFileRecordService{
	
	
	@Value("${PAGE_DEFAULT_SIZE}")
    private Integer PAGE_DEFAULT_SIZE;
	@Autowired
	private PetrolFillRecordMapper petrolFillRecordMapper;

	@Override
	public PageInfo<PetrolFillRecordVo> getAllPetrol(Integer now, Integer size, PetrolFillRecordVo petrolFillRecordVo,
			String address, String name, String realName) {
         
		if(now == null || now<1 ) {
			now = 1;
		}
		if(size == null  ) {
			size = PAGE_DEFAULT_SIZE;
		}
		
		PageHelper.startPage(now,size);
		
		PetrolFillRecordVo pt = new PetrolFillRecordVo();
		if(address != null && !"".equals(address)){
			pt.setAddress(address);
		}
		if(name != null && !"".equals(name)){
			pt.setName(name);
		}
		if(realName != null && !"".equals(realName)){
			pt.setRealName(realName);
		}
		List<PetrolFillRecordVo> list = petrolFillRecordMapper.getAllPetrol(petrolFillRecordVo);
		PageInfo<PetrolFillRecordVo> pageInfo = new PageInfo<>(list);
		return pageInfo;
		
		
		
	}

	@Override
	public PetrolFillRecord getById(Integer id) {
		
		return petrolFillRecordMapper.selectByPrimaryKey(id);
	}

	@Override
	public void updatePetrolFillRecord(PetrolFillRecord petrolFillRecord) {
		petrolFillRecordMapper.getStatus(petrolFillRecord);
		
	}

}
