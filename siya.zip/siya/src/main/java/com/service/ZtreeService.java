package com.service;

import java.util.List;

import com.entity.Auth;

public interface ZtreeService {

	
	public List<Auth> getZtree();
}
