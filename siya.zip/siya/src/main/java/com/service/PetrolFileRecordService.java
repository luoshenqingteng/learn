package com.service;



import com.github.pagehelper.PageInfo;
import com.vo.PetrolFillRecordVo;
import com.entity.PetrolFillRecord;
/**
 * 加油记录
 * @param now
 * @param size
 * @param petrolFillRecordVo
 * @param address
 * @param name
 * @param realName
 * @return
 */
public interface PetrolFileRecordService {
	
	PageInfo<PetrolFillRecordVo> getAllPetrol(Integer now,Integer size,PetrolFillRecordVo petrolFillRecordVo,String address,String name,String realName);
	
	PetrolFillRecord getById(Integer id);
	
	void updatePetrolFillRecord(PetrolFillRecord petrolFillRecord);
	

}
