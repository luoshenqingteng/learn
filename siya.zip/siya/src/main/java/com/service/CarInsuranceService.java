package com.service;

import com.entity.CarInsurance;
import com.github.pagehelper.PageInfo;
/**
 * ����
 * @author yw
 *
 */
public interface CarInsuranceService {
	
	PageInfo<CarInsurance> getCarInsurance(Integer size,Integer now,String name,String driveLicense,String licensePlate);

	CarInsurance getById(Integer id);
	
	void updateCar(CarInsurance carInsurance);
}
