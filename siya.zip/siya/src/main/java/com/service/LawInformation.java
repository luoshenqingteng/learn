package com.service;

import java.util.List;

import com.entity.Information;
import com.github.pagehelper.PageInfo;

public interface LawInformation {
	
	
	PageInfo<Information> getlawInformation(Integer size,Integer now,Information information);

}
