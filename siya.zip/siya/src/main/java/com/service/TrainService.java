package com.service;

import com.entity.PetrolStation;
import com.entity.Train;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;

public interface TrainService {
	
	PageInfo<Train> getTrain(Integer now,Integer size,Train train,String author,String title);
	
	Train getById(Integer id);
	
	void updateTrain(Train train);

}
