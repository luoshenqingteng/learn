package com.service;

import java.util.List;

import com.entity.Insurance;
import com.github.pagehelper.PageInfo;
import com.vo.InsuranceVo;
/**
 * ����
 * @author yw
 *
 */
public interface InsuranceService {
	
	PageInfo<InsuranceVo> getInsurance(Integer now,Integer size,String realName,String beneficiary,String body,String homeplace,String occupation,String company);
	
	Insurance getById(Integer id);
	
	void updateInsurance(Insurance insurance);

}
