package com.service;

import com.github.pagehelper.PageInfo;
import com.vo.PetrolStationAndPetrolVo;

public interface PetrolStationAndPetrolService {
	
	PageInfo<PetrolStationAndPetrolVo> getStationPetrol(Integer now,Integer size,
			PetrolStationAndPetrolVo PetrolStationAndPetrolVo,String address,String name,String cname);

}
