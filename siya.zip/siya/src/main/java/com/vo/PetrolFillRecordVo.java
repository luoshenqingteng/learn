package com.vo;

import com.entity.PetrolFillRecord;

import lombok.Data;
/**
 * ���ͼ�¼
 * @author yw
 *
 */

@Data
public class PetrolFillRecordVo extends PetrolFillRecord{
	
	 private String address;
	 private String mobile;
	 private String idCard;
	 private String realName;
	 private String name;
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

}
