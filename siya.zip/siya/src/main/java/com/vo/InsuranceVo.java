package com.vo;

import com.entity.Insurance;

import lombok.Data;
/**
 * ����
 * @author yw
 *
 */

@Data
public class InsuranceVo extends Insurance{

	
	
	private String realName;
	private String mobile;
	private Boolean sex;
	private String username;
}
