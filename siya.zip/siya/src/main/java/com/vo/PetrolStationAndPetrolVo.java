package com.vo;

import com.entity.PetrolStationAndPetrol;

import lombok.Data;
/**
 * ����վ�͵���Ϣ
 * @author yw
 *
 */
@Data
public class PetrolStationAndPetrolVo extends PetrolStationAndPetrol{
	
	private String name;
	private String cname;
	private String address;

}
